var valorUm = 17;
var valorDois = 3;

var totalAdicao = valorUm + valorDois;
document.write("Valor da Adição: " + totalAdicao + "<br>");

var totalSubtracao = valorUm - valorDois;
document.write("Valor da Subtração: " + totalSubtracao + "<br>");

var totalMultiplicacao = valorUm * valorDois;
document.write("Valor da Multiplicação: " + totalMultiplicacao + "<br>");

var totalDivisao = valorUm / valorDois;
document.write("Valor da Divisão: " + totalDivisao + "<br>");

var totalResto = valorUm % valorDois;
document.write("Valor do Resto: " + totalResto + "<br>");

